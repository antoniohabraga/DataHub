# DataHub
Desafio DataHub


Para compilação do código é necessário usar o spring boot initializer e abrir a pasta com Eclipse IDE, depois executar o código "Controller.java" no Eclipse IDE, logo após executá-lo basta acessar "localhost:8080" em seu navegador, assim exibirá o retorno do código escrito.
